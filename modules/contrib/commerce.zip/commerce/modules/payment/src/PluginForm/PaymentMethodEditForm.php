<?php

namespace Drupal\commerce_payment\PluginForm;

/**
 * @todo
 */
class PaymentMethodEditForm extends PaymentMethodAddForm {

}
